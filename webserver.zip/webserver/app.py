from flask import Flask
app = Flask(__name__)

@app.route("/")
def homepage():
    return """
    <!DOCTYPE html>
    <html lang="en">
      <head>
        <meta charset="UTF-8">
        <title>ScienceZone</title>
        <style>
  @font-face {
                font-family: 'MyCoolFont';
                src: url('/static/CyberTechMonogram.ttf');
            }


            .custom-font {
                font-family: 'MyCoolFont', sans-serif;
                font-size: 76px;
            }

            .center-title {
                text-align: center;
                margin-top: 50px;
            }

            body {
                background-color: #f0f0f0;
            }

            img {
                display: block;
                margin: 20px auto;
                max-width: 50%;
            }

          /* Fixed logo styles */
          #sz-logo {
            position: fixed;
            top: 0;
            left: 0;
            width: 100px;
            height: auto;
            z-index: 1000;
          }
          /* Avoid content underlapping the fixed logo */
          body {
            padding-top: 120px;
            padding-left: 120px;
          }
        </style>
      </head>
      <body>
        <!-- Logo in the top-left corner -->
        <a href="https://www.sciencezone.uk">
          <img id="sz-logo" src="/static/szlogo.png" alt="ScienceZone Logo">
        </a>

        <!-- Rest of your page content below... -->
         <h1 class=" center-title">Welcome to</h1>
         <h1 class="custom-font center-title">Chris's Pi</h1>
        <img src="/static/pi.png" alt="My Image">
        <!-- ... -->
      </body>
    </html>
    """

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')